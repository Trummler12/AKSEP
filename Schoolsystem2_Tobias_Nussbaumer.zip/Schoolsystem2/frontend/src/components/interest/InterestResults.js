// Tabelle wie /topics, aber Score-Spalte
