// Name, ID, Type, Layer, Description, Links
