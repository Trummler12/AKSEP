// einzelne Ressource (inkl. eingebettetes Video, falls YouTube)
