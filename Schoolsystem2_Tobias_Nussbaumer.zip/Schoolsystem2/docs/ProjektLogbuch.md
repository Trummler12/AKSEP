# Projekt-Logbuch

---

## Inhaltsverzeichnis

1. [Idee](#1-idee)
2. [Umsetzung](#2-umsetzung)
   - [M1: Anforderungsanalyse](#m1-anforderungsanalyse)
   - [M2: Entwurf](#m2-entwurf)
   - [M3: Implementierung](#m3-implementierung)
   - [M4: Test](#m4-test)
3. [Learnings](#3-learnings)


---

## 1. Idee

Eine alte Version der Planung findet sich in [./legacy/PLANUNG.md](./legacy/PLANUNG.md).

## 2. Umsetzung

### M1: Anforderungsanalyse

#### Praktische Umsetzung

Siehe [USE_CASES.md](./USE_CASES.md);  
Deckt sich zwar nicht wirklich mit der Theorie der "Anforderungsanalyse", aber in der Eile immerhin besser als nix

#### Theoretische Untermauerung

(Keine Zeit mehr für theoretische Untermauerung :sob:)


### M2: Entwurf

#### Praktische Umsetzung

#### Theoretische Untermauerung


### M3: Implementierung

#### Praktische Umsetzung

Irgendwas funktioniert noch nicht aaaaah  
ABGABE

#### Theoretische Untermauerung


### M4: Test

#### Praktische Umsetzung

Unit-Tests bis zu einem gewissen Zeitpunkt, danach 

#### Theoretische Untermauerung



## 3. Learnings

Ein full-on Java-Projekt ist WEITAUS komplexer und vielschichtiger als ich erwartet hätte;  
Zudem muss ich künftig unbedingt schauen - und dies bei JEDEM Projekt & Auftrag, dass ich es zu gewährleisten schaffe, dass ich Umstände schaffe, welche mich immer nur exakt ein einziges Projekt/Auftrag als objektiv am wichtigsten wahrnehmen lassen; Das mit diesem Projekt hier war wieder eine Katastrophe, da ich ständig (bis Mittwoch der letzten Woche vor Abgabe) mich ständig ablenken und in die Prokrastination reiten liess, weil die Existenz eines Betriebsprojektes und die Zusammenstellung von Bewerbungsunterlagen für das Praktikum ständig von diesem Projekt hier haben ablenken lassen;

Sie wollen noch was Fachliches hören? Dat reiche ich vielleicht bis zum Vortrag noch nach, aber jetzt war schon Mitternacht und ich hab' noch nicht abgegeben und ich hasse mein Hirn deswegen - UND WARUM REQUEST FAILED AAAH

